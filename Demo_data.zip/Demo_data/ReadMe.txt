File Structure
=========
Demo_for_train.xlsx              Training data containing in-situ RWT observations
Demo_for_prediction/          Daily input data, with each file named by date  (e.g., 2021-01-01.xlsx)
Demo_result/                        Output folder where the estimated RWT is appended as the last column of the corresponding .xlsx file



Usage
=========
To estimate RWT for a specific date, place the input data as an Excel file named after that date (e.g., 2021-01-01.xlsx) into the Demo_for_prediction/ folder. The reconstructed RWT will be automatically appended as the last column in the output file saved to Demo_result/.
Note: Ensure the input filename matches the target date in YYYY-MM-DD.xlsx format.